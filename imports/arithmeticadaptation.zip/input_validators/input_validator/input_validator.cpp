#include "validation.h"

int main(int argc, char *argv[]) {
    InputValidator v(argc, argv);
    int s = v.read_integer("s", -999, 999);
    v.newline();
    return 0;
}
