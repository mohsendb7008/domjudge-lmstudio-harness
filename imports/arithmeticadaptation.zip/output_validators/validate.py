#!/usr/bin/env python3

import sys
from pathlib import Path
from typing import Union


def fail(judge_msg: str, team_msg: Union[str, None] = None) -> None:
    """Fail WA with given message"""
    if team_msg == None:
        team_msg = judge_msg
    with (
        open(sys.argv[3] / Path("judgemessage.txt"), "a", encoding="utf-8") as jfile,
        open(sys.argv[3] / Path("teammessage.txt"), "a", encoding="utf-8") as tfile,
    ):
        jfile.write(f"WA: {judge_msg}\n")
        tfile.write(f"{team_msg}\n")
    sys.exit(43)


def accept() -> None:
    sys.exit(42)


def get_team_answer() -> list[str]:
    team_bytes = sys.stdin.buffer.read()
    try:
        team_lines = team_bytes.decode("utf-8").splitlines()
    except UnicodeDecodeError:
        fail("Submission contains unexpected characters")
    if not team_lines:
        fail("Submission produces empty output")
    return team_lines


with open(sys.argv[1]) as in_file, open(sys.argv[2]) as ans_file:
    s = int(in_file.readline())

    team = " ".join(get_team_answer())
    team_tokens = team.split()
    if len(team_tokens) != 2:
        fail(f"Submission produces {len(team_tokens)} tokens; expected exactly 2")
    a_str, b_str = team.split()
    for token in (a_str, b_str):
        try:
            num = float(a_str)
        except ValueError:
            fail(f"Token {token} is not numeric")

        if not num.is_integer():
            fail(f"Unable to parse {token} as an integer or int-like float")

    a, b = int(float(a_str)), int(float(b_str))
    if not (-999 <= a <= 999 and -999 <= b <= 999):
        fail(f"{a} or {b} out of range", "both a and b must each have at most three digits")
    if a == 0 or b == 0:
        fail(f"a={a} or b={b} equals zero", "both a and b must each be nonzero")
    if not a + b == s:
        fail(f"a={a} and b={b} sum to {a+b}, not input {s}", "a and b must sum to s")
    accept()
