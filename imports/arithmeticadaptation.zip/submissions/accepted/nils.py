#!/usr/bin/env python3
import random

n = int(input())

while True:
    x = random.randint(-999,999)
    y = n-x
    if x != y and -999 <= y <= 999 and x*y != 0:
        print(x, y)
        break
