#!/usr/bin/env python3
n = int(input())

for a in range(-999, 1000):
    for b in range(-999, 1000):
        if a != 0 != b and a + b == n:
            print(a,b)
            break
    else:
        continue
    break
