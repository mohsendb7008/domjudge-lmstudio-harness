# Pick random a of the same sign as s

import random

random.seed(0)

s = int(input())
rng = set(range(-999, 0) if s < 0 else range(1, 1000)) - {s}
a = random.choice(list(rng))
b = s - a
print(a, b)
