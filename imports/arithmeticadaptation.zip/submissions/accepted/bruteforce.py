#!/usr/bin/env python3
import sys

s = int(input())

for a in range(-999, 1000):
    for b in range(-999, 1000):
        if a and b and a + b == s:
            print(a, b)
            sys.exit(0)

assert False # never reached
