n = int(input())
if n > 1 or n==-1:
    print(n-1, 1)
else:
    print(n+1, -1)
