n = int(input())
if n > 1 or n==-1:
    print(f"{n-1}.001", 1)
else:
    print(n+1, -1.001)
