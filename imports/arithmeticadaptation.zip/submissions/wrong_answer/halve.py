#!/usr/bin/env python3
import math

n = int(input())

a = math.ceil((n/2))
b = math.floor((n/2))
assert a + b == n
print(a, b)
