#!/usr/bin/env pyton3

print(input(), 0)
