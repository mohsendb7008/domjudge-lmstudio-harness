import random

def arithmetic() -> tuple:
    str_input = input()
    random_number = random.randint(-100, 100)
    sample_input = int(str_input)
    a = random_number % (sample_input + 30)
    return sample_input - a, a

if __name__=='__main__':
    print(arithmetic())
