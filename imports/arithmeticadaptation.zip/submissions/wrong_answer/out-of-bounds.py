#!/usr/bin/env python3

n = int(input())
if n >= 0:
    print(n+1, -1)
else:
    print(n-1, +1)
