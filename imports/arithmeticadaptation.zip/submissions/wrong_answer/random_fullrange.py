# Wrong solution using random a in {-999, ..., 999} - {0, s} and b = s - a.
# This fails when s and a are far apart, because then b > 1000

import random

random.seed(0)

s = int(input())
rng = set(range(-999, 1000)) - {0, s}
a = random.choice(list(rng))
b = s - a
print(a, b)
