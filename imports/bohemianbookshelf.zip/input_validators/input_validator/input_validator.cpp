#include "validation.h"

int main(int argc, char *argv[]) {
    InputValidator v(argc, argv);
    int N = v.read_integer("N", 2, 100);
    v.space();
    int H = v.read_integer("H", 130, 350);
    v.space();
    int W = v.read_integer("W", 300, 900);
    v.newline();
    int maxdimension = (W > H) ? W : H;
    int minheight = (483 < maxdimension) ? 483 : maxdimension;
    for (int i = 0; i < N; ++i) {
	    v.read_integer("h", 76, minheight);
	    v.space();
	    v.read_integer("t", 5, 60);
	    v.newline();
    }
    return 0;
}
