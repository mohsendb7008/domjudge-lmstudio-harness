# All books that are too tall must be stacked. If no books are stacked this way, 
# stack the fattest book. Then put the rest upright


N, H, W = map(int, input().split())

books = [tuple(map(int, input().split())) for _ in range(N)]


upright = []
stacked = []

for i in range(N):
    if books[i][0] > H:
        stacked.append(i + 1)

if not stacked:
    j, mx = 0, books[0][1]
    for i in range(1, N):
        if books[i][1] > mx:
            j, mx = i, books[i][1]
    stacked.append(j + 1)

stacked.sort(key = lambda i: books[i - 1][0], reverse = True)
for i in range(N):
    if i + 1 not in stacked:
        upright.append(i + 1)

if sum(books[i-1][1] for i in stacked) > H:
    print ('impossible')
elif sum(books[i-1][1] for i in upright) + max(books[i-1][0] for i in stacked)  > W:
    print ('impossible')
else:
    print('upright', *upright)
    print('stacked', *stacked)
