import sys

N, H, W = map(int, input().split())
books = []
for _ in range(N):
    h, t = map(int, input().split())
    books.append((h, t))

def partition_range(r):
    nums = list(range(r))
    for mask in range(1 << r):
        a = []
        b = []
        for i, num in enumerate(nums):
            if mask & (1 << i):
                a.append(num)
            else:
                b.append(num)
        yield a, b

solutions = 0
for stacked, shelved in partition_range(N):
    if (not stacked or not shelved or
        max(books[idx][0] for idx in shelved) > H or
        sum(books[idx][1] for idx in stacked) > H or
        sum(books[idx][1] for idx in shelved) + max(books[idx][0] for idx in stacked) > W):
        continue

    if solutions == 0:
        print("upright", *(idx + 1 for idx in shelved))
        sortedstack = sorted(stacked, key = lambda i: -books[i][0])
        print("stacked", *(idx + 1 for idx in sortedstack))
        print()
    solutions += 1

if solutions == 0:
    print("impossible")

print(solutions, file=sys.stderr)
