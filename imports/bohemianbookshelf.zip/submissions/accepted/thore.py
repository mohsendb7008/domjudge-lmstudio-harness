#!/usr/bin/env/python3
import sys

N, H, W = map(int, input().split())

books = [tuple(map(int, input().split())) for _ in range(N)]

def solve(base_id):
    """ Solve the instance described by books, assuming that the base_id'th book
    forms the base of a base stack.
    """

    stack_width = books[base_id][0]

    # filled[i] = dict mapping (w, h) to a tuple in filled[i-1]
    # if there is a way to fill the bookcase with width w upright
    # books and a stack of height h using the first i books.
    # Invariantly, we have w <= W - stackwidth, h <= H
    filled: list[dict[tuple[int, int], tuple[int, int]]] = [{ (0,0) : None }]
    for i in range(N):
        hi, ti = books[i]
        current = dict()
        for w, h in filled[-1]:
            if i != base_id and w + ti <= W - stack_width and hi <= H:
                current[w + ti, h] = w, h
            if h + ti <= H and hi <= stack_width:
                current[w, h + ti] = w, h
        filled.append(current)
    return filled
    
for j in range(N):
    f = solve(j)

    if len(f) < N:
        continue
    for w, h in f[-1]:
        if w == 0:
            continue
        break
    else:
        continue
    assert w > 0 and h > 0
    assert w <= W - books[j][0] and h <= H

    # Found a solution, now recover it
    upright = []
    stacked = []
    #print(f)
    for i in range(N, 0, -1):
        hi, ti = books[i - 1]
        if f[i][w,h] == (w - ti, h):
            upright.append(i)
            w -= ti
            assert i - 1 != j
        elif f[i][w,h] == (w, h - ti):
            stacked.append(i)
            h -= ti
        else:
            assert False
    assert w == h == 0
    assert len(upright) + len(stacked) == N
    stackwidth = max(books[i-1][0] for i in stacked)
    width = sum(books[i-1][1] for i in upright) + stackwidth
    assert stackwidth == books[j][0], (stackwidth, books[j][0], j)
    assert width <= W, (W, width, upright, stacked)
    assert (books[i-1][0] <= H for i in upright)
    stackheight = sum(books[i-1][1] for i in stacked)
    assert stackheight <= H
    print('upright', *upright)
    print('stacked', *(reversed(sorted(stacked, key=lambda i: books[i - 1][0]))))
    #print(width, stackheight, file = sys.stderr)
    break
else:
    print('impossible')
