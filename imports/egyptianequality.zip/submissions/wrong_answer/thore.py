#!/usr/bin/env python3
import sys

_ = int(input())
lines = sys.stdin.readlines()
total_copper = sum(line.count('C') for line in lines)
if total_copper % 2 != 0:
    print('Impossible')
else:
    part = 'A'
    claimed_copper = 0
    for line in lines:
        for char in line.strip():
            if char == '#':
                print('#', end='')
            else:
                print(part, end='')
                if char == 'C':
                    claimed_copper += 1
                    if claimed_copper == total_copper // 2:
                        part = 'B'
        print()
