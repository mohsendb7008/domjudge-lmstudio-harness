#!/usr/bin/env python3

dx = [1,0,0,-1]
dy = [0,1,-1,0]

def in_bounds(r, c):
    return r >= 0 and c >= 0 and r < n and c < 2*n-1

def in_pyramid(r, c):
    if r+c < n-1 or r+2*n-2-c < n-1 or not in_bounds(r, c):
        return False
    return True

def check(part):
    if len(part) == 0:
        return False
    start = part[0]
    part_set = set(part)
    seen = set()
    copper = 0
    q = [start]
    while len(q) > 0:
        r, c = q[-1]
        q.pop()
        if (r, c) not in seen:
            seen.add((r, c))

            if (r, c) in mines_set:
                copper += 1

            for i in range(4):
                r2 = r + dx[i]
                c2 = c + dy[i]
                if in_pyramid(r2, c2) and (r2, c2) in part_set:
                    q.append((r2, c2))
    return (len(seen) == len(part) and copper == m // 2)

def solve(order, no_stop=0):
    copper = 0
    part1 = []
    part2 = []
    its = 0
    for (r, c) in order:
        if copper < m // 2 or its < no_stop:
            part1.append((r, c))
        else:
            part2.append((r, c))
        if (r, c) in mines_set:
            copper += 1
        its += 1
    
    if not (check(part1) and check(part2)):
        return False
    ans = [['#']*(2*n-1) for _ in range(n)]
    for (r, c) in part1:
        ans[r][c] = 'A'
    for (r, c) in part2:
        ans[r][c] = 'B'
    for row in ans:
        print("".join(row))
    return True 

def get_order(i):
    pairs = []
    for (r, c) in all_cells:
        if i == 0:
            x = 10**6 * (n - r) + min(c,2*n-2-c)
        if i == 1:
            x = r + c
        if i == 2:
            x = r - c
        pairs.append((x, r, c))
    order = []
    pairs.sort()
    for _, r, c in pairs:
        order.append((r, c))
    return order

def impossible():
    bad_set = {(0,n-1),(1,n-1),(n-1,0),(n-1,1),(n-1,2*n-3),(n-1,2*n-2)}
    return m % 2 == 1 or (n == 2 and m == 4) or (m == 6 and mines_set == bad_set)

n = int(input())
mines = []
    
for r in range(n):
    row = input()
    for c in range(2*n-1):
        if row[c] == 'C':
            mines.append((r, c))
    
all_cells = []
for r in range(n):
    for c in range(2*n-1):
        if in_pyramid(r, c):
            all_cells.append((r, c))

m = len(mines)
mines_set = set(mines)

if impossible():
    print("Impossible")
else:
    done = False
    for i in [0,1]:
        order = get_order(i)
        if solve(order, 2*n-1):
            done = True
            break
