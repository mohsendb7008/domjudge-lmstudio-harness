#!/usr/bin/env python3

n = int(input())
m = 0
grid = [[0]*(2*n-1) for _ in range(n)]

for r in range(n):
    row = input()
    for c in range(2*n-1):
        if row[c] == 'C':
            m += 1
            grid[r][c] = 1
        else:
            grid[r][c] = 0

if m%2 == 1:
    print("impossible")
else:
    ans = [['B']*(2*n-1) for _ in range(n)]
    a = 0
    for r in range(n):
        for c in range(2*n-1):
            a += grid[r][c]
            ans[r][c] = 'A'
            if a == m//2:
                break
        if a == m//2:
            break
    for r in range(n):
        print("".join(ans[r]))

