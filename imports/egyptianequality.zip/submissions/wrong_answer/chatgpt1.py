#!/usr/bin/env python3

import sys

def main():
    data = sys.stdin.read().strip().splitlines()
    N = int(data[0].strip())
    rows = [list(data[i+1].rstrip("\n")) for i in range(N)]
    W = 2 * N - 1

    # Build a Hamiltonian path that snakes through the pyramid.
    path = []  # list of (r, c)
    for r in range(N):
        row = rows[r]
        # Find leftmost and rightmost Pyramidland cells on this row
        l = 0
        while l < W and row[l] == '#':
            l += 1
        rr = W - 1
        while rr >= 0 and row[rr] == '#':
            rr -= 1
        # Safety (should not happen for valid input)
        if l > rr:
            print("Impossible")
            return
        if r % 2 == 0:
            for c in range(l, rr + 1):
                path.append((r, c))
        else:
            for c in range(rr, l - 1, -1):
                path.append((r, c))

    # Count total mines
    total_mines = sum(1 for (r, c) in path if rows[r][c] == 'C')

    if total_mines % 2 == 1:
        print("Impossible")
        return

    target = total_mines // 2

    # Choose cut position so that the prefix has exactly target mines.
    # If target == 0 (i.e., no mines at all), cut after first cell to keep both parts non-empty.
    cut = None
    if target == 0:
        cut = 1
    else:
        cum = 0
        for i, (r, c) in enumerate(path, start=1):
            if rows[r][c] == 'C':
                cum += 1
            if cum == target:
                cut = i
                break
        # As total_mines > 0 and target < total_mines, such a cut must exist before the end.

    if cut is None or cut <= 0 or cut >= len(path):
        # Extremely defensive; should not happen for valid inputs with even total mines.
        print("Impossible")
        return

    # Build output labeling: first `cut` cells are 'A', rest are 'B'
    out = [row[:] for row in rows]
    for idx, (r, c) in enumerate(path):
        out[r][c] = 'A' if idx < cut else 'B'

    # Print result
    for r in range(N):
        print(''.join(ch if ch == '#' else out[r][c]
                      for c, ch in enumerate(rows[r])))

if __name__ == "__main__":
    main()
