#!/usr/bin/env python3

rows = int(input())
cols = 2 * rows - 1
C = { (r, c) for r in range(rows) for c, ch in enumerate(input()) if ch == "C" }
B = {(rows - 1, c) for c in range(cols)}
L = {(r, rows - r - 1) for r in range(rows)} | { (r, rows - r - 0) for r in range(1, rows) }
R = {(r, rows + r - 1) for r in range(rows)} | { (r, rows + r - 2) for r in range(1, rows) }


def greedy(order):
    solution = {}
    archeologist = "A"
    stones = 0
    for r, c in sorted(((r, c) for r in range(rows) for c in range(cols)), key=order):
        if rows - r - 1 <= c < rows + r:
            if (r, c) in C:
                if stones == len(C) // 2:
                    archeologist = "B"
                stones += 1
            solution[r, c] = archeologist
        else:
            solution[r, c] = "#"
    return solution

orders = {
    "rising-flood": lambda s: rows * (rows - s[0]) + min(s[1], cols - s[1] - 1),
    "diagonal-slash": lambda s: s[0] + s[1],
    "diagonal-backslash": lambda s: s[0] - s[1],
}

if (
    len(C) % 2 == 1
    or len(C) == 4 and rows == 2
    or len(C) == 6 and len(C & L) == len(C & R) == len(C & B) == 4
):
    print("impossible")
else:
    if len(L & C) <= len(C) // 2:
        partition = greedy(orders["diagonal-slash"])
    elif len(R & C) <= len(C) // 2:
        partition = greedy(orders["diagonal-backslash"])
    elif len(B & C) <= len(C) // 2:
        partition = greedy(orders["rising-flood"])
    else:
        assert False

    for r in range(rows):
        print("".join(partition[r, c] for c in range(cols)))
