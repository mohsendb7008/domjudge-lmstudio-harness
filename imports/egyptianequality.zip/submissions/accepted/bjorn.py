#!/usr/bin/env python3
n = int(input())
m = 2 * n - 1

mat = [input() for _ in range(n)]

stones = 0
for row in mat:
    stones += row.count('C')

if stones % 2:
    print('impossible')
    exit()

def is_stone(i, j):
    return mat[i][j] == 'C'

def print_order(order):
    mat3 = [['#']*m for _ in range(n)]
    marked = 0
    order.reverse()
    while order:
        i,j = order[-1]
        if marked + is_stone(i,j) > stones//2:
            break
        order.pop()
        mat3[i][j] = 'A'
        marked += is_stone(i,j)
    
    while order:
        i,j = order.pop()
        mat3[i][j] = 'B'

    for row in mat3:
        print(''.join(row))

path1 = [(n - 1, j) for j in range(m)]
path2 = [(n - 1 - j, j) for j in range(n)] + [(n - 1 - j + 1, j) for j in range(1, n)]
path3 = [(i, m - 1 - j) for i,j in path2]

sum1 = sum(is_stone(*p) for p in path1)
sum2 = sum(is_stone(*p) for p in path2)
sum3 = sum(is_stone(*p) for p in path3)

if sum1 <= stones//2:
    order = []
    for i in range(n)[::-1]:
        for j in range(n - i - 1, n - 1):
            order.append((i, j))
            order.append((i, m - 1 - j))
        order.append((i, n - 1))
    print_order(order)
elif sum2 <= stones//2:
    order = [(i,j) for i in range(n) for j in range(m) if mat[i][j] != '#']
    order.sort(key = lambda i: (i[0] + i[1], i[0]))
    print_order(order)
elif sum3 <= stones//2:
    order = [(i,j) for i in range(n) for j in range(m) if mat[i][j] != '#']
    order.sort(key = lambda i: (i[0] - i[1], i[0]))
    print_order(order)
else:
    print('impossible')
