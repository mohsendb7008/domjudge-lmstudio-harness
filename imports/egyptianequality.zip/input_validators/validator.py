#!/usr/bin/python3
import sys
import re

line = sys.stdin.readline()
assert re.match("^[1-9][0-9]*\n$", line)
n = int(line)
for i in range(n):
    line = sys.stdin.readline()
    assert re.match("^[#.C]*\n$", line)
    line = list(line.strip())
    assert len(line) == 2 * n - 1
    for j in range(n - i - 1):
        assert line[j] == '#'
        assert line[-j-1] == '#'
        line[j] = '.'
        line[-j-1] = '.'
    assert '#' not in line

assert sys.stdin.read() == ""

sys.exit(42)
