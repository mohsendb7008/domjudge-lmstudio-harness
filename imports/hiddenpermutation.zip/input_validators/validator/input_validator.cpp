#include "validation.h"

#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(i, a) for(auto& i : a)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;

const int MAXN = 100;
const int MAXK = 1000;
const int MAXP = 1000000000;

__int128 to_int128(string& s) {
    __int128 result = 0;
    for (int i = 0; i < s.size(); i++) {
        int digit = s[i] - '0';
        assert(0 <= digit && digit <= 9);
        if(i == 0)assert(digit != 0);
        result = result * 10 + digit;
    }
    return result;
}

__int128 power2(int x){
    __int128 res = 1;
    for(int i = 0; i < x; i++){
        res *= 2;
    }
    return res;
}

string LineStop(char stop){
  string ret;
	for (;;) {
		char ch = IO::Char();
		if (ch == stop) break;
		ret += ch;
	}
	return ret;
}

void run() {
  int n = Int(2, MAXN);
  Space();
  int k = Int(1, MAXK);
  Endl();

  vector<int> P = SpacedInts(k, 1, MAXP);

  rep(c1,1,k){
    assert(P[c1] > P[c1-1]);
  }

  rep(c1,0,k){
    char stop = ' ';
    if(c1 == k-1)stop = '\n';
    string xs = LineStop(stop);
    __int128 x = to_int128(xs);
    assert(x <= power2(100));
    assert(x >= 1);
  }


}
