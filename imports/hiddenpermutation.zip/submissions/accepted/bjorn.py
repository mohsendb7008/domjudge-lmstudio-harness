#!/usr/bin/env python3


import sys
input = sys.stdin.readline

n,k = [int(x) for x in input().split()]

P = [int(x) for x in input().split()]
M = [int(x) for x in input().split()]

# Convert M to powers of 2 C
# Where C[i] = 2 ** sum(gcd(c,i) for c in cycles)
C = [0] * (n + 1)
for p,m in zip(P, M):
    for d in range(p, n + 1, p):
        C[d] += m

def is_power_2(x):
    return x & (x - 1) == 0 and x > 0

# In correct input, C[1:] should only contain powers of 2
if not all(is_power_2(x) for x in C[1:]):
    print("impossible")
    exit()

# Now C[i] = sum(gcd(c,i) for c in cycles)
C = [x.bit_length() - 1 for x in C]

def solve(mat, b):
    from fractions import Fraction as f

    mat = [row[:] for row in mat]

    n = len(b)

    for row in A:
        row[:] = [f(x, 1) for x in row]

    b = [f(x, 1) for x in b]
    
    # Solve using gaussian elimination and fractional numbers
    for i in range(n):
        i2 = i
        while mat[i2][i] == 0:
            i2 += 1
        
        mat[i2], mat[i] = mat[i], mat[i2]
        b[i2], b[i] = b[i], b[i2]

        x = mat[i][i]
        b[i] /= x
        for j in range(i, n):
            mat[i][j] /= x

        for i2 in range(i + 1, n):
            x = -mat[i2][i]

            b[i2] += x * b[i]
            for j in range(n):
                mat[i2][j] += x * mat[i][j]
    

    for i in range(n)[::-1]:
        x = mat[i][i]
        b[i] /= x
        for j in range(i, n):
            mat[i][j] /= x
        
        for i2 in range(i):
            x = -mat[i2][i]

            b[i2] += x * b[i]
            mat[i2][i] = 0

    return b

# Invert C[i] = sum(gcd(c,i) for c in cycles)
# to find cycles

from math import gcd
A = [[gcd(i,j) for j in range(1, n + 1)] for i in range(1, n + 1)]
X = [0] + solve(A, C[1:])

if any(x != int(x) or x < 0 for x in X):
    print("impossible")
    exit()

X = [int(x) for x in X]

if sum(i*x for i,x in enumerate(X)) != n:
    print("impossible")
    exit()

cycles = [i for i,x in enumerate(X) for _ in range(x)]

# Check that P is correct

# P should be equal to all divisors of lcm(*cycles)
from math import lcm
prod = lcm(*cycles)

prime_factors = set()
for c in cycles:
    for p in range(2, 4 * 10**4):
        if c % p == 0:
            prime_factors.add(p)
            while c % p == 0:
                c //= p
    if c > 1:
        prime_factors.add(c)

divs = [1]
for p in prime_factors:
    e = 0
    while prod % p == 0:
        prod //= p
        e += 1

    divs = [d * p**i for d in divs for i in range(e + 1)]

    if len(divs) > k:
        print("impossible")
        exit()

divs.sort()
if divs != P:
    print("impossible")
    exit()

# Check that P is correct done


# Check that M is correct

from collections import defaultdict
M2 = defaultdict(int)
for d in divs:
    M2[d] = 2 ** sum(gcd(c, d) for c in cycles)

# Reverse what we did earlier to get powers of 2
for d in divs:
    for d2 in divs:
        if d2 < d and d % d2 == 0:
            M2[d] -= M2[d2]

M3 = [M2[d] for d in divs]

if M != M3:
    print("impossible")
    exit()

# Check that M is correct done

perm = []
for c in cycles:
    base = len(perm)
    cycle = list(range(base, base + c))
    cycle.append(cycle.pop(0))
    perm += cycle

print(*[x + 1 for x in perm])
