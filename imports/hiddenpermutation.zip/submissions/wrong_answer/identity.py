#!/usr/bin/env python3

n,k = map(int,input().split())
ans = [i+1 for i in range(n)]
print(*ans)
