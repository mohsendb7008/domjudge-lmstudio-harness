#!/usr/bin/env python3

import random

n,k = map(int,input().split())
ans = [i+1 for i in range(n)]
random.shuffle(ans)
print(*ans)
