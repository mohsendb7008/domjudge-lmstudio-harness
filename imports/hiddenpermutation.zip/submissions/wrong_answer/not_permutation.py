#!/usr/bin/env python3

import random

n,k = map(int,input().split())
ans = [random.randint(1, n) for _ in range(n)]
print(*ans)
