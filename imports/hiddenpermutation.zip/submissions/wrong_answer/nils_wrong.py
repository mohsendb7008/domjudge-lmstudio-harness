#!/usr/bin/env python3

from copy import deepcopy

# Quite slow solution, does bigint calculations
# But fast enough on current bounds

MAXN = 130
MAXK = 300000

def LOG(x):
    for i in range(101):
        if 2**i == x:
            return i
    return -1

def gcd(i, j):
    if j == 0:
        return i
    return gcd(j,i%j)


def fail():
    print("impossible")
    exit()


# Matrix inverse from pyrival:
vec_mul = lambda mat, vec: [sum(a * b for a, b in zip(row, vec)) for row in mat]

def mat_inv(A):
    B = deepcopy(A)
    n = len(A)
    col = list(range(n))

    tmp = [[0] * n for _ in range(n)]
    for i in range(n):
        tmp[i][i] = 1

    for i in range(n):
        r = c = i
        for j in range(i, n):
            for k in range(i, n):
                if abs(B[j][k]) > abs(B[r][c]):
                    r, c = j, k
        if B[r][c] == 0:
            return B

        B[i], B[r] = B[r], B[i]
        tmp[i], tmp[r] = tmp[r], tmp[i]
        for j in range(n):
            B[j][i], B[j][c] = B[j][c], B[j][i]
            tmp[j][i], tmp[j][c] = tmp[j][c], tmp[j][i]
        col[i], col[c] = col[c], col[i]
        v = B[i][i]
        for j in range(i + 1, n):
            f = B[j][i] / v
            B[j][i] = 0
            for k in range(i + 1, n):
                B[j][k] -= f * B[i][k]
            for k in range(n):
                tmp[j][k] -= f * tmp[i][k]

        for j in range(i + 1, n):
            B[i][j] /= v

        for j in range(n):
            tmp[i][j] /= v
        B[i][i] = 1

    for i in reversed(range(n)):
        for j in range(i):
            v = B[j][i]
            for k in range(n):
                tmp[j][k] -= v * tmp[i][k]

    for i in range(n):
        for j in range(n):
            B[col[i]][col[j]] = tmp[i][j]
    return B
##

def factor(x):
    M = {}
    for d in range(2, x+1):
        f = 0
        if x%d == 0:
            while x%d == 0:
                x //= d
                f += 1
            M[d] = f
    return M

def LCM(cycles):
    prime_f = [0] * (MAXN+1)
    for c in cycles:
        M = factor(c)
        for d in M:
            prime_f[d] = max(prime_f[d], M[d])
    pairs = []
    for d in range(MAXN+1):
        if prime_f[d] > 0:
            pairs.append((d, prime_f[d]))
    return pairs

def divisors(primes, i):
    if i == len(primes):
        return [1]
    divs = divisors(primes, i+1)
    p, f = primes[i]
    res = []
    t = 1
    for _ in range(f+1):
        divs2 = divs.copy()
        for j in range(len(divs2)):
            divs2[j] *= t
        res += divs2
        t *= p
    return res

def get_x(cycles):
    pairs = LCM(cycles)
    num_divs = 1
    for _, f in pairs:
        num_divs *= (f+1)
    assert num_divs <= MAXK
    divs = divisors(pairs, 0)
    divs.sort()
    Y = []
    for d in divs:
        sumg = 0
        for c in cycles:
            sumg += gcd(c, d)
        Y.append(2**sumg)
    X = Y.copy()

    for i in range(len(divs)):
        for j in range(i+1, len(divs)):
            if divs[j]%divs[i] == 0:
                X[j] -= X[i]
    ans = []
    for i in range(len(divs)):
        ans.append((divs[i], X[i]))
    return ans

def tc(n, X):
    print(n, len(X))
    for a,b in X:
        print(a,b)

def create_permutation(cycles):
    res = []
    for c in cycles:
        extra = len(res)+1
        for i in range(c):
            res.append((i+1)%c + extra)
    return res

n,k = map(int,input().split())
Y = [0] * (n+1)
YL = [0] * (n+1)

PF = []

P = list(map(int, input().split()))
F = list(map(int, input().split()))

for i in range(k):
    p, f = P[i], F[i]
    PF.append((p, f))
    if p <= n:
        d = p
        while d <= n:
            Y[d] += f
            d += p

for i in range(1,n+1):
    YL[i] = LOG(Y[i])
    if YL[i] == -1:
        fail()

RHS = YL[1:]
GCD = [[0]*n for _ in range(n)]

for i in range(1, n+1):
    for j in range(1, n+1):
        GCD[i-1][j-1] = gcd(i, j)

INV = mat_inv(GCD)
C = vec_mul(INV, RHS)

cycles = []
for i in range(n):
    x = round(C[i])
    cycles += [i+1]*x

if sum(cycles) != n:
    fail()

print(*create_permutation(cycles))
