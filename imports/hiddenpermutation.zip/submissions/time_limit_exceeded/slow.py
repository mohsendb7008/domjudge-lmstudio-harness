#!/usr/bin/env python3

def get_partitions(n, mi):
    if n == 0:
        return [[]]
    if mi > n:
        return []
    res = []
    for smallest in range(mi, n+1):
        temp = get_partitions(n-smallest, smallest)
        for v in temp:
            res.append([smallest] + v)
    return res

def create_permutation(cycles):
    res = []
    for c in cycles:
        extra = len(res)
        for i in range(c):
            res.append((i+1)%c + extra)
    return res

def period(b, p):
    b2 = b.copy()
    res = 0
    while True:
        res += 1
        b3 = []
        for i in range(n):
            b3.append(b2[p[i]])
        b2 = b3
        if b2 == b:
            return res

MAXN = 101
n,k  = map(int, input().split())
X = [0] * MAXN

P = list(map(int, input().split()))
F = list(map(int, input().split()))

for i in range(k):
    f, x = P[i], F[i]
    if f < MAXN:
        X[f] = x

parts = get_partitions(n, 1)

for part in parts:
    p = create_permutation(part)
    X2 = [0] * MAXN
    for mask in range(2**n):
        mask2 = mask
        b = []
        for i in range(n):
            b.append(mask2%2)
            mask2//=2
        x = period(b, p)
        X2[x] += 1
    if X2 == X:
        for x in p:
            print(x+1, end=" ")
        print("")
        exit()
print("impossible")

