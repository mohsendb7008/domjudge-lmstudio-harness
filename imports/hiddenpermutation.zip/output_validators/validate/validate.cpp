#include "validate.h"
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

typedef long long ll;
typedef __int128 lll;

const string FAIL = "impossible";

__int128 to_int128(string& s) {
    __int128 result = 0;
    for (int i = 0; i < s.size(); i++) {
        int digit = s[i] - '0';
        result = result * 10 + digit;
    }
    return result;
}

bool validate_permutation(vector<int> P){
    sort(P.begin(), P.end());
    for(int i = 0; i < P.size(); i++){
        if(P[i] != i+1)return 0;
    }
    return 1;
}

vector<ll> get_cycles(vector<int> P){
    vector<int> seen(P.size(), 0);
    vector<ll> res;
    for(int c1 = 0; c1 < P.size(); c1++){
        P[c1]--;
    }
    for(int c1 = 0; c1 < P.size(); c1++){
        if(!seen[c1]){
            int c = 1;
            seen[c1] = 1;
            int a = P[c1];
            while(seen[a] == 0){
                c++;
                seen[a] = 1;
                a = P[a];
            }
            res.push_back(c);
        }
    }
    return res;
}

ll gcd(ll i, ll j){
    if(j == 0)return i;
    return gcd(j, i%j);
}

ll lcm(vector<ll> nums){
    // since n <= 100 this won't overflow, otherwise we will have to do something more complicated
    ll res = 1;
    for(auto x : nums){
        res = (res*x) / gcd(res, x);
    }
    return res;
}

__int128 power2(int x){
    __int128 res = 1;
    for(int i = 0; i < x; i++){
        res *= 2;
    }
    return res;
}

vector<ll> get_divisors(ll x){
    vector<ll> res;
    for(ll d = 1; d*d <= x; d++){
        if(x%d == 0){
            res.push_back(d);
            if(d*d != x){
                res.push_back(x/d);
            }
        }
    }
    sort(res.begin(), res.end());
    return res;
}

int parse_first_string(string s){
    // -2: invalid
    // -1: impossible
    // else: p_1
    for(auto &c : s){
        c = tolower(c);
    }
    if(s == FAIL)return -1;
    if(s.length() > 7)return -2;
    int x = 0;
    for(auto c : s){
        if(!('0' <= c && c <= '9'))return -2;
        x *= 10;
        x += c-'0';
    }
    return x;
}

int main(int argc, char **argv) {
    init_io(argc, argv);

    int n,k; 
    judge_in >> n >> k;
    vector<int> period(k);
    vector<__int128> X(k);

    for(int i = 0; i < k; i++){
        judge_in >> period[i];
    }

    for(int i = 0; i < k; ++i) {
        string xs;
        judge_in >> xs;
        X[i] = to_int128(xs);
    }

    // Get sum over divisors of X (easier to check against constestants answer)
    vector<__int128> Y(k, 0);
    for(int c1 = 0; c1 < k; c1++){
        for(int c2 = 0; c2 < k; c2++){
            if(period[c1]%period[c2] == 0){
                Y[c1] += X[c2];
            }
        }
    }
    vector<pair<int,__int128> > PY;
    for(int c1 = 0; c1 < k; c1++){
        PY.push_back({period[c1], Y[c1]});
    }
    sort(PY.begin(), PY.end());

    int first_judge_number, first_contestant_number;
    string js, cs;
    judge_ans >> js;
    first_judge_number = parse_first_string(js);

    if(!(author_out >> cs)){
        wrong_answer("Could not read first string/number");
    }
    first_contestant_number = parse_first_string(cs);
    if(first_contestant_number == -2){
        wrong_answer("Did not print 'impossible' or a number");
    }

    if(first_judge_number != -1 && first_contestant_number == -1){
        wrong_answer("Contestant printed 'impossible' but a solution existed"); 
    }

    if(first_contestant_number != -1){
        vector<int> P = {first_contestant_number};
        for(int i = 1; i < n; i++){
            int x;
            if(!(author_out >> x)){
                wrong_answer("Could not read %dth number", i+1);
            }
            P.push_back(x);
        }
        if(!validate_permutation(P)){
            wrong_answer("Not a valid permutation");
        }

        // All periods are divisors of LCM of cycle lengths
        vector<ll> cycs = get_cycles(P);
        ll LCM = lcm(cycs);
        vector<ll> divs = get_divisors(LCM);
        
        vector<pair<int, __int128>> PY_contestant;
    
        for(auto d : divs){
            int sum_gcd = 0;
            for(auto c : cycs){
                sum_gcd += gcd(d, c);
            }
            PY_contestant.push_back({d, power2(sum_gcd)});
        }

        if(PY_contestant != PY){
            wrong_answer("Permutation provided by contestant did not have the correct period counts");
        }
        
        if(first_judge_number == -1){
            judge_error("Judge said 'impossible' but contestant found a solution");
        }
    }
    
    string trailing;
    if(author_out >> trailing) {
        wrong_answer("Wrong answer: Trailing output.\n");
    }

    accept();
}
