#include<iostream>
using namespace std;
typedef long long ll;

int main() {
    ll n, e, pos = 0;
    cin >> n >> e;
    while(e > 0) {
        pos += e;
        if(pos % n == 0) e++;
        else e--;
    }
    cout << pos << '\n';
}
