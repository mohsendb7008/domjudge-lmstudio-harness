#include<iostream>
#include<map>
using namespace std;
typedef long long ll;

int main() {
    ll n, e, pos = 0;
    map<pair<ll,ll>,ll> seen;
    cin >> n >> e;
    while(e > 0) {
        auto key = make_pair(pos % n, e % n);
        if(seen.count(key) && seen[key] <= e) {
            cout << "infinity\n";
            return 0;
        }
        seen[key] = e;
        pos += e;
        if(pos % n == 0) e++;
        else e--;
    }
    cout << pos << '\n';
}
