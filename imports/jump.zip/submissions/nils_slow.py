#!/usr/bin/env python3

# This runs in O(E) where E <= 10^9, but it has a pretty good constant factor 
# and runs well within a second with pypy... 
# Oh well we can let it through I guess

def solve_slow(n,f):
    cyc = [(0, f%n)]
    xm = 0
    fm = f%n
    pref = 0
    min_pref = 0
    pref_sum = 0
    while True:
        xm += fm
        xm %= n
        if xm%n != 0:
            fm -= 1
            pref -= 1
        else:
            fm += 1
            pref += 1
        min_pref = min(pref, min_pref)
        fm %= n
        if (xm, fm) == cyc[0]:
            break
        pref_sum += pref
        cyc.append((xm, fm))
    
    if f+min_pref > 0 and pref >= 0:
        return "infinity"

    # this part is slow
    ans = 0
    while f+min_pref > 0:
        ans += len(cyc)*f + pref_sum
        f += pref
    
    while f > 0:
        ans += f
        if ans%n == 0:
            f += 1
        else:
            f -= 1 
    
    return ans

print(solve_slow(*map(int, input().split())))
