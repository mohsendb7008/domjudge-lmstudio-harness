#!/usr/bin/env python3

def solve_fast(n,f):
    cyc = [(0, f%n)]
    xm = 0
    fm = f%n
    pref = 0
    min_pref = 0
    pref_sum = 0
    while True:
        xm += fm
        xm %= n
        if xm%n != 0:
            fm -= 1
            pref -= 1
        else:
            fm += 1
            pref += 1
        min_pref = min(pref, min_pref)
        fm %= n
        if (xm, fm) == cyc[0]:
            break
        pref_sum += pref
        cyc.append((xm, fm))
    
    if f+min_pref > 0 and pref >= 0:
        return "infinity"

    ans = 0
    laps = 0
    if pref < 0: # potential bug?
        laps = (f+min_pref) // (-pref) - 1
        laps = max(laps, 0)

    ans += len(cyc)*(laps * f + pref * (laps*laps-laps) // 2) + pref_sum*laps
    f += pref*laps
    
    while f > 0:
        ans += f
        if ans%n == 0:
            f += 1
        else:
            f -= 1 
    
    return ans

print(solve_fast(*map(int, input().split())))
