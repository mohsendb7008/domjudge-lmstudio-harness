#include<iostream>
#include<chrono>
using namespace std;
typedef long long ll;

int main() {
    auto start = chrono::system_clock::now();
    ll n, e, pos = 0;
    cin >> n >> e;
    while(e > 0) {
        pos += e;
        if(pos % n == 0) e++;
        else e--;
        auto end = chrono::system_clock::now();
        auto elapsed = chrono::duration_cast<chrono::milliseconds>(end - start);
        if(chrono::milliseconds(elapsed).count() > 900) {
            cout << "infinity\n";
            return 0;
        }
    }
    cout << pos << '\n';
}
