#include <bits/stdc++.h>
using namespace std;

using ii = pair<int, int>;
using ld = long double;

ld Dist(ld x, ld y) { return sqrt(x * x + y * y); }

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<ii> xy(n);
    for (auto& [x, y] : xy)
        cin >> x >> y;
    auto p = *ranges::min_element(xy);
    auto byDist = [&p](auto& a, auto& b) {
        return Dist(a.first - p.first, a.second - p.second) <
                Dist(b.first - p.first, b.second - p.second);
    };
    ranges::sort(xy, byDist);
    ld res = 0;
    for (int i = 1; i < n; i++)
        res += Dist(xy[i].first - xy[i - 1].first, xy[i].second - xy[i - 1].second);
    cout << fixed << setprecision(10) << res << "\n";
    return 0;
}
