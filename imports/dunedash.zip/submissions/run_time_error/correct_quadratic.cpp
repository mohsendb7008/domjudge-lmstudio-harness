#include <bits/stdc++.h>
using namespace std;

using ii = pair<int, int>;
using ld = long double;
using ldii = pair<ld, ii>;

// Quadratic solution that should get TLE or run out of memory, whichever happens first.
// If it gets TLE, just move it

struct UnionSet {
    vector<int> par, siz;
    UnionSet(int n): par(n), siz(n, 1) {
        iota(par.begin(), par.end(), 0);
    }
    int getPar(int x) { return par[x] == x ? x : par[x] = getPar(par[x]); }
    bool Union(int a, int b) {
        a = getPar(a), b = getPar(b);
        if (a == b)
            return false;
        if (siz[a] < siz[b])
            swap(a, b);
        siz[a] += siz[b];
        par[b] = a;
        return true;
    }
};

ld Dist(ld x, ld y) { return sqrt(x * x + y * y); }

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<ii> xy(n);
    for (auto& [x, y] : xy)
        cin >> x >> y;
    vector<ldii> E;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            E.push_back({Dist(xy[i].first - xy[j].first, xy[i].second - xy[j].second),
                {i, j}});
    ranges::sort(E);
    UnionSet US(n);
    ld res = 0;
    for (auto& [dist, ab] : E)
        if (US.Union(ab.first, ab.second))
            res += dist;
    cout << fixed << setprecision(10) << res << "\n";
    return 0;
}
