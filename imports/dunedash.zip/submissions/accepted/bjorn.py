#!/usr/bin/env python3
import sys
input = sys.stdin.buffer.readline

X = []
Y = []
n = int(input())
for _ in range(n):
    x,y = [int(x) for x in input().split()]
    X.append(x)
    Y.append(y)

def dist(i, j):
    return (X[i] - X[j])**2 + (Y[i] - Y[j])**2

start = max(range(n), key = lambda j: dist(0, j))
path = sorted(range(n), key = lambda j: dist(start, j))

print(sum(dist(i,j)**0.5 for i,j in zip(path, path[1:])))
