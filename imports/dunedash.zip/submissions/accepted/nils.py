#!/usr/bin/env python3

def dist(p1, p2):
    return (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2

n = int(input())
pts = []

for _ in range(n):
    x, y = map(int,input().split())
    pts.append((x, y))

ma = -1
endpoint = -1

for i in range(1, n):
    d = dist(pts[0], pts[i])
    if d > ma:
        ma = d
        endpoint = i

di = []

for i in range(0, n):
    d = dist(pts[i], pts[endpoint])
    di.append((d, i))

di.sort()

ans = 0

for i in range(1, n):
    i1 = di[i-1][1]
    i2 = di[i][1]
    ans += (dist(pts[i1], pts[i2])) ** 0.5

print(ans)

