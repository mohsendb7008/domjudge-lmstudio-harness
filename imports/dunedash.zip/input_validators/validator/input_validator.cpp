#include "validation.h"

#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(i, a) for(auto& i : a)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;

const int MAXN = 200000;
const int MAXX = 1000000000;

ll dist2(pll p1, pll p2){
    return (p1.first-p2.first)*(p1.first-p2.first) + (p1.second-p2.second)*(p1.second-p2.second);
}

vector<pair<ll,ll> > pts;
pair<ll,ll> endpoint;

bool comp(pair<ll,ll> p1, pair<ll,ll> p2){
    return dist2(p1, endpoint) < dist2(p2, endpoint);
}

void run() {
  int n = Int(2, MAXN);
  Endl();

  set<pii> point_set;

  rep(c1,0,n){
    ll x = Int(-MAXX, MAXX);
    Space();
    ll y = Int(-MAXX, MAXX);
    Endl();
    point_set.insert({x, y});
    pts.push_back({x, y});
  }

  // distinct points
  assert(sz(point_set) == n);

  // find endpoint of race
  ll max_distance = -1;
  rep(c1,1,n){
    ll d = dist2(pts[0], pts[c1]);
    if(d > max_distance){
        max_distance = d;
        endpoint = pts[c1];
    }
  }

  // sort by distance from endpoint
  sort(all(pts), comp);

  // check simplified version of condition
  for(int k = 0; k < n; k++){
    for(int i = 0; i < k-1; i++){
        ll d = dist2(pts[i], pts[k]);
        assert(d > dist2(pts[i], pts[k-1]) && d > dist2(pts[i+1], pts[k]));
    }
  }


}
