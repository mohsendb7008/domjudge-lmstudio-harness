#include "validate.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <random>
#include <set>
#include <vector>

using namespace std;
using int_t = int64_t;

struct union_find_t {
    vector<int_t> parent;
    vector<set<int_t>> group_colors;
    union_find_t(int_t n, vector<int_t>& color) : parent(n), group_colors(n) {
        for (int_t i = 0; i < n; i++) {
            parent[i] = i;
            group_colors[i].insert(color[i]);
        }
    }

    int_t find(int_t x) {
        return parent[x] = (x == parent[x] ? x : find(parent[x]));
    }

    bool unite(int_t x, int_t y) {
        int_t xp = find(x);
        int_t yp = find(y);
        if (xp == yp) return false;
        if (group_colors[xp].size() < group_colors[yp].size()) swap(xp, yp);
        parent[yp] = xp;
        group_colors[xp].insert(group_colors[yp].begin(), group_colors[yp].end());
        group_colors[yp].clear();
        return true;
    }
    
    int_t count_unique(int_t x) {
        return ssize(group_colors[find(x)]);
    }
};

int main(int argc, char **argv) {
    init_io(argc, argv);

    int_t n, m, k;
    judge_in >> n >> m >> k;

    string answer_token;
    judge_ans >> answer_token;
    if (answer_token == "impossible") {
        string author_token;
        author_out >> author_token;
        transform(begin(author_token), end(author_token), begin(author_token), ::tolower);
        if (author_token != "impossible") {
            wrong_answer("Wrong answer: Program did not output \"impossible\" when it is impossible.\n");
        }
    }
    else {
        vector<int_t> colors(n);
        for (auto& x : colors) {
            if (!(author_out >> x)) {
                wrong_answer("Wrong answer: Ill formed output. Perhaps author claims impossibility when solution exists.\a");
            }
            if (!(1 <= x && x <= k)) {
                wrong_answer("Wrong answer: Game version out of bounds.\n");
            }
        }

        union_find_t uf(n, colors);
        
        for (int_t i = 0; i < m; i++) {
            int_t a, b;
            judge_in >> a >> b;
            a--, b--;
            uf.unite(a, b);
        }

        for (int_t i = 0; i < n; i++) {
            assert(0 <= uf.count_unique(i) && uf.count_unique(i) <= k);
            if (uf.count_unique(i) < k) {
                wrong_answer("Wrong answer: Person %d can only obtain Pokémon from %d out of %d game versions.\n", i+1, uf.count_unique(i), k);
            }
        }
    }

    author_out >> ws;
    string trash;
    if (author_out >> trash) {
        wrong_answer("Wrong answer: Trailing output.\n");
    }

    accept();
}
