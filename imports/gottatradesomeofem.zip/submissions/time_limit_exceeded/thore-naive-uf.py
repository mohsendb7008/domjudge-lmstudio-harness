from collections import defaultdict

n, m, k = map(int, input().split())
parent = { i: i for i in range(1, n + 1) }

def find(x):
    while parent[x] != x:
        x = parent[x]
    return x

def union(x, y):
    parent[find(y)] = find(x)

for _ in range(m):
    union(*map(int, input().split()))

components: dict[int, int] = defaultdict(int)
solution = []
for i in range(1, n + 1):
    j = find(i)
#    print(i, j)
    components[j] = min(components[j] + 1, k)
    solution.append(components[j])
#print(components, solution)
print(*solution if set(components.values()) == {k} else ["impossible"])







