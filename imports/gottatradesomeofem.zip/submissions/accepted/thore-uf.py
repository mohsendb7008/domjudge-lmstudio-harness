from collections import defaultdict

n, m, k = map(int, input().split())

parent = {}
rank: dict[int, int] = defaultdict(int)


def find(x):
    """Iterative find with path compression"""
    if x not in parent:
        parent[x] = x
    root = x
    while parent[root] != root:
        root = parent[root]
    while x != root:
        parent[x], x = root, parent[x]
    return root


def union(x, y):
    """Union by rank"""
    rx, ry = find(x), find(y)
    if rx == ry:
        return
    if rank[rx] < rank[ry]:
        parent[rx] = ry
    elif rank[rx] > rank[ry]:
        parent[ry] = rx
    else:
        parent[ry] = rx
        rank[rx] += 1


for _ in range(m):
    union(*map(int, input().split()))

components: dict[int, int] = defaultdict(int)
solution = []
for i in range(1, n + 1):
    j = find(i)
    components[j] = min(components[j] + 1, k)
    solution.append(components[j])
print(*solution if set(components.values()) == {k} else ["impossible"])
