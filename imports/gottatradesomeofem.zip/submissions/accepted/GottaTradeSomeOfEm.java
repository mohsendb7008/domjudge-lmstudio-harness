import java.io.*;
import java.util.*;

public class GottaTradeSomeOfEm {

    static int[] parent;
    static int[] rank;

    static int find(int x) {
        // Iterative find with path compression
        if (parent[x] == 0) parent[x] = x; // lazily initialize

        int root = x;
        while (parent[root] != root) {
            root = parent[root];
        }

        // Path compression
        while (x != root) {
            int tmp = parent[x];
            parent[x] = root;
            x = tmp;
        }
        return root;
    }

    static void union(int x, int y) {
        int rx = find(x);
        int ry = find(y);
        if (rx == ry) return;

        if (rank[rx] < rank[ry]) {
            parent[rx] = ry;
        } else if (rank[rx] > rank[ry]) {
            parent[ry] = rx;
        } else {
            parent[ry] = rx;
            rank[rx]++;
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());

        int n = Integer.parseInt(st.nextToken());
        int m = Integer.parseInt(st.nextToken());
        int k = Integer.parseInt(st.nextToken());

        parent = new int[n + 1]; // 1-based indexing
        rank = new int[n + 1];   // default 0

        // process unions
        for (int i = 0; i < m; i++) {
            st = new StringTokenizer(br.readLine());
            int a = Integer.parseInt(st.nextToken());
            int b = Integer.parseInt(st.nextToken());
            union(a, b);
        }

        // component sizes capped at k
        Map<Integer, Integer> components = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        boolean valid = true;

        for (int i = 1; i <= n; i++) {
            int root = find(i);
            int count = components.getOrDefault(root, 0) + 1;
            if (count > k) count = k;
            components.put(root, count);
            sb.append(count).append(" ");
        }

        // check if all components reached size exactly k
        Set<Integer> values = new HashSet<>(components.values());
        if (values.size() == 1 && values.contains(k)) {
            System.out.println(sb.toString().trim());
        } else {
            System.out.println("impossible");
        }
    }
}
