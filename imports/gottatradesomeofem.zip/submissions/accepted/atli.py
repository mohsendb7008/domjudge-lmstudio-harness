def dfs(g, k, s, col):
    new, stk = [], [s]
    col[s] = 1
    while len(stk) > 0:
        cur = stk[-1]
        stk.pop()
        new.append(cur)
        for x in g[cur]:
            if col[x] == 0:
                stk.append(x)
                col[x] = 1
    if len(new) < k:
        print("impossible")
        exit(0)
    for i in range(k):
        col[new[i]] = i + 1
n, m, k = map(int, input().strip().split())
g = [[] for _ in range(n)]
for _ in range(m):
    a, b = map(int, input().strip().split())
    a, b = a - 1, b - 1
    g[a].append(b)
    g[b].append(a)
col = [0 for _ in range(n)]
for i in range(n):
    if col[i] == 0:
        dfs(g, k, i, col)
print(" ".join(str(x) for x in col))
