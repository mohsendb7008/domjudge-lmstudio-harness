import sys

sys.stdout.buffer.write(b"\xff")
