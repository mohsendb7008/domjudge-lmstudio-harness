
#!/usr/bin/env python3

days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

day1, time1 = input().split()
day2, time2 = input().split()

def get_minutes(d,h,m):
    return 24 * 60 * d + 60 * h + m

time1 = get_minutes(days.index(day1), *[int(x) for x in time1.split(':')])
time2 = get_minutes(days.index(day2), *[int(x) for x in time2.split(':')])

week = get_minutes(7,0,0)


diff = (time2 - time1) % week
diff += week * (diff == 0)


m = diff%60
diff //= 60

h = diff%24
diff //= 24

d = diff


out = []
if d:
    if d == 1:
        out.append("1 day")
    else:
        out.append("%d days" % d)

if h:
    if h == 1:
        out.append("1 hour")
    else:
        out.append("%d hours" % h)

if m:
    if m == 1:
        out.append("1 minute")
    else:
        out.append("%d minutes" % m)

if len(out) == 2:
    print(' and '.join(out))
else:
    print(', '.join(out))
