#!/usr/bin/env python3

week_map = {"Mon": 0, "Tue": 1, "Wed": 2, "Thu": 3, "Fri": 4, "Sat": 5, "Sun": 6}

def to_time(line):
    hour, minute = line[1].split(':')
    return 24*60*week_map[line[0]] + 60*int(hour) + int(minute)

def to_string(d):
    res = []
    if d >= 24*60:
        days = d // (24*60)
        s = str(days) + " days"
        if days == 1:
            s = str(days) + " day"
        res.append(s)
        d %= (24*60)
    if d >= 60:
        hours = d // 60
        s = str(hours) + " hours"
        if hours == 1:
            s = str(hours) + " hour"
        res.append(s)
        d %= 60
    if d > 0:
        s = str(d) + " minutes"
        if d == 1:
            s = str(d) + " minute"
        res.append(s)
    if len(res) == 1:
        return res[0]
    if len(res) == 2:
        return res[0] + " and " + res[1]
    return res[0] + ", " + res[1] + ", " + res[2]

line1 = input().split()
line2 = input().split()

d = (to_time(line2) - to_time(line1)) % (7*24*60)
if d == 0:
    d = 7*24*60
print(to_string(d))

