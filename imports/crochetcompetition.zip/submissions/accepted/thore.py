def parse_weektime(s: str) -> int:
    """Convert 'Day HH:MM' into minutes since Monday 00:00."""
    weekday, time = s.split()
    hours, minutes = map(int, time.split(':'))
    weekdaycount = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].index(weekday)
    return weekdaycount * 24 * 60 + hours * 60 + minutes

def diff_minutes(start: str, finish: str) -> tuple[int, int, int]:
    diff = parse_weektime(finish) - parse_weektime(start)
    if diff < 0:
        diff += 7 * 24 * 60  # wrap around a week
    days, rem = divmod(diff, 24 * 60)
    hours, minutes = divmod(rem, 60)
    return days, hours, minutes

d, h, m = diff_minutes(input(), input())
if d == h == m == 0:
    d = 7

res = []
if d:
    res.append(f"{d} day{'' if d == 1 else 's'}")
if h:
    res.append(f"{h} hour{'' if h == 1 else 's'}")
if m:
    res.append(f"{m} minute{'' if m == 1 else 's'}")

if len(res) == 1:
    print(*res)
if len(res) == 2:
    print(' and '.join(res))
if len(res) == 3:
    print(', '.join(res))
