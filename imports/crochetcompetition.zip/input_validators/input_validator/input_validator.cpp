#include "validation.h"

std::regex hhmm("^([01][0-9]|2[0-3]):[0-5][0-9]$");

int main(int argc, char *argv[]) {
	InputValidator v(argc, argv);
	for (int i = 0; i < 2; ++i) {
		v.test_strings({"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"});
		v.space();
		std::string time = v.read_string("time", 5, 5, ":0123456789");
		v.check(std::regex_match(time, hhmm), "Invalid time format");
		v.newline();
	}
	return 0;
}
