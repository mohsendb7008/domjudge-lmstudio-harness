#! /usr/bin/env python3

latest = None
for _ in range(int(input())):
    sign = input()
    if sign[0] == '/':
        assert latest is not None
        speed = ((latest + 9) // 10) * 10
    else:
        speed = int(sign)
        if latest is None:
            latest = speed
    print(speed)
