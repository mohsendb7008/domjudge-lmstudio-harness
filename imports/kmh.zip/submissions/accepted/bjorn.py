#!/usr/bin/env python3

n = int(input())

m = -1
for _ in range(n):
    s = input()
    if s == '/':
        m2 = m + 1
        while m2 % 10:
            m2 += 1
        print(m2)
    else:
        d = int(s)
        print(d)
        m = max(m, d)
