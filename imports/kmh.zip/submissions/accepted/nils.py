#!/usr/bin/env python3

national = [10*i for i in range(1, 18)]

n = int(input())

prev = -1
ma = 0

for i in range(n):
    speed = input()
    if speed != '/':
        speed = int(speed)
        prev = speed
        if speed%10 == 0 and speed in national:
            national.remove(speed)
        print(speed)
        ma = max(ma, speed)
    else:
        x = 0
        for s in national:
            if s > ma:
                x = s
                break
        print(x)
