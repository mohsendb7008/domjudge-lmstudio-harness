#! /usr/bin/env python3

seen_speeds: set[int] = set()
for _ in range(int(input())):
    sign = input()
    if sign[0] == '/':
        speed = ((max(seen_speeds) + 9) // 10) * 10
        if speed == max(seen_speeds):
            speed += 10
    else:
        speed = int(sign)
        seen_speeds.add(speed)
    print(speed)
