#! /usr/bin/env python3
signs = tuple(input() for _ in range(int(input())))
for i, s in enumerate(signs):
    print(s if s != '/' else (max(int(ss) for ss in signs[:i] if ss != '/') // 10 + 1) * 10)
