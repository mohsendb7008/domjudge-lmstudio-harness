#! /usr/bin/env python3

max_seen = -1
for _ in range(int(input())):
    sign = input()
    if sign[0] == '/':
        speed = (max_seen // 10 + 1) * 10
    else:
        speed = int(sign)
        max_seen = max(max_seen, speed)
    print(speed)
