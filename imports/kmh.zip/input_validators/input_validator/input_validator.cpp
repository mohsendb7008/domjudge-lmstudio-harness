#include "validation.h"

// Check the grammar of the input files.
// You should also check properties of the input.
// E.g., check that a graph is connected.

int main(int argc, char *argv[]) {
	InputValidator v(argc, argv);
	int N = v.read_integer("N", 1, 100);
	v.newline();
	bool limit_required = true;
	for (int i = 0; i < N; ++i) {
		if (!limit_required && v.peek('/')) {
		       	v.test_string("/");
			limit_required = true;
		}
		else {
			int L =  v.read_integer("L", 10, 160);
			limit_required = false;
		}
		v.newline();
	}
	return 0;
}
