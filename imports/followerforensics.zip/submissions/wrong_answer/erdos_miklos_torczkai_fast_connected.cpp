#include <algorithm>
#include <iostream>
#include <map>
#include <optional>
#include <set>
#include <vector>

using namespace std;

using int_t = int64_t;

using edge_t = pair<int_t, int_t>;

struct vertex_t {
    int_t label;
    int_t outdegree;
    int_t indegree;
};

struct normal_order_in {
    bool operator()(const vertex_t a, const vertex_t b) const {
        return a.indegree == b.indegree ? (a.outdegree == b.outdegree ? a.label < b.label : a.outdegree > b.outdegree)
                                        : a.indegree > b.indegree;
    }
};

struct normal_order_out {
    bool operator()(const vertex_t a, const vertex_t b) const {
        return a.outdegree == b.outdegree ? (a.indegree == b.indegree ? a.label < b.label : a.indegree > b.indegree)
                                          : a.outdegree > b.outdegree;
    }
};

struct indegree_ascending {
    bool operator()(const vertex_t a, const vertex_t b) const {
        return a.indegree == b.indegree ? (a.outdegree == b.outdegree ? a.label < b.label : a.outdegree < b.outdegree)
                                        : a.indegree < b.indegree;
    }
};

struct outdegree_ascending {
    bool operator()(const vertex_t a, const vertex_t b) const {
        return a.outdegree == b.outdegree ? (a.indegree == b.indegree ? a.label < b.label : a.indegree < b.indegree)
                                          : a.outdegree < b.outdegree;
    }
};

struct erdos_miklos_toroczkai{
    vector<vertex_t> sequence;
    set<vertex_t, indegree_ascending> pick_order_in;
    set<vertex_t, outdegree_ascending> pick_order_out;
    set<vertex_t, normal_order_in> ordered_by_in;
    set<vertex_t, normal_order_out> ordered_by_out;
    optional<vector<edge_t>> result{ nullopt };

    void insert(const vertex_t& d) {
        if (d.outdegree > 0) {
            pick_order_out.insert(d);
        }
        if (d.indegree > 0) {
            pick_order_in.insert(d);
        }
        if (d.indegree + d.outdegree > 0) {
            ordered_by_in.insert(d);
            ordered_by_out.insert(d);
        }
    }

    void remove(const vertex_t& d) {
        pick_order_in.erase(d);
        pick_order_out.erase(d);
        ordered_by_in.erase(d);
        ordered_by_out.erase(d);
    }

    bool should_pick_indegree() {
        if (pick_order_out.empty()) {
            return true;
        }
        else if (pick_order_in.empty() || pick_order_out.begin()->outdegree < pick_order_in.begin()->indegree) {
            return false;
        }
        return true;
    }

    erdos_miklos_toroczkai(const vector<vertex_t>& sequence) : sequence(sequence) {
        int_t m = 0;
        for (const auto d : sequence) {
            insert(d);
            m += d.outdegree;
        }

        vector<edge_t> edges;
        edges.reserve(m);

        while (!ordered_by_in.empty()) {
            bool pick_in{ should_pick_indegree() };
            if (pick_in ? pick_order_in.empty() : pick_order_out.empty()) {
                return;
            }
            vertex_t d_n{ pick_in ? *pick_order_in.begin() : *pick_order_out.begin() };

            remove(d_n);

            vector<vertex_t> updates;
            updates.reserve(pick_in ? d_n.indegree : d_n.outdegree);
            while ((pick_in ? d_n.indegree : d_n.outdegree) > 0) {
                if (pick_in ? ordered_by_out.empty() : ordered_by_in.empty()) {
                    return;
                }
                vertex_t d{ pick_in ? *ordered_by_out.begin() : *ordered_by_in.begin() };
                updates.push_back(d);
                remove(d);
                (pick_in ? d_n.indegree : d_n.outdegree)--;
            }

            for (auto d : updates) {
                if ((pick_in ? d.outdegree : d.indegree) == 0) {
                    return;
                }
                (pick_in ? d.outdegree : d.indegree)--;
                edges.push_back({pick_in ? d.label : d_n.label, pick_in ? d_n.label : d.label });
                insert(d);
            }
            insert(d_n);
        }

        result = edges;
    }
};

int main() {
    int_t n;
    cin >> n;
    vector<vertex_t> sequence(n);
    for (int_t i = 0; i < n; i++) {
        sequence[i].label = i;
    }
    for (int_t i = 0; i < n; i++) {
        cin >> sequence[i].outdegree;
    }
    for (int_t i = 0; i < n; i++) {
        cin >> sequence[i].indegree;
    }

    const auto result{ erdos_miklos_toroczkai(sequence).result };

    if (result.has_value()) {
        cout << n << " " << result->size() << '\n';
        for (auto [a, b] : result.value()) {
            cout << a + 1 << " " << b + 1 << '\n';
        }
    }
    else {
        cout << "impossible" << endl;
    }
    return 0;
}
