from itertools import combinations

n = int(input())
seq_from = list(map(int, input().split()))
seq_to = list(map(int, input().split()))

all_edges = [(i, j) for i in range(n) for j in range(n) if i != j]

for k in range(len(all_edges) + 1):
    for comb in combinations(all_edges, k):
        count_from = [0 for _ in range(n)]
        count_to = [0 for _ in range(n)]
        edges = []
        for (u, v) in comb:
            count_from[u] += 1
            count_to[v] += 1
            edges.append((u,v))
        if count_from == seq_from and count_to == seq_to:
            m = len(edges)
            print(f"{n} {m}")
            for (u, v) in edges:
                print(f"{u+1} {v+1}")
            exit()
print("impossible")
