#include <algorithm>
#include <iostream>
#include <optional>
#include <map>
#include <set>
#include <vector>

using namespace std;

using int_t = int64_t;

using edge_t = pair<int_t, int_t>;

struct vertex_t {
    int_t label;
    int_t outdegree;
    int_t indegree;
};

bool operator<(const vertex_t a, const vertex_t b) {
    return a.indegree == b.indegree ?
            (a.outdegree == b.outdegree ? a.label < b.label : a.outdegree > b.outdegree) :
            a.indegree > b.indegree;
}

void insert(set<vertex_t>& ordered, map<int_t, vertex_t>& vertices_to_pick, vertex_t d) {
    if (d.outdegree > 0) vertices_to_pick[d.label] = d;
    if (d.indegree + d.outdegree > 0) ordered.insert(d);
}

optional<vector<edge_t>> erdos_miklos_toroczkai(vector<vertex_t> sequence) {
    map<int_t, vertex_t> vertices_to_pick;
    set<vertex_t> ordered;

    int_t m = 0;
    for (const auto d : sequence) {
        insert(ordered, vertices_to_pick, d);
        m += d.outdegree;
    }

    vector<edge_t> edges;
    edges.reserve(m);

    while (!ordered.empty()) {
        if (vertices_to_pick.empty()) {
            return nullopt;
        }
        vertex_t d_n{ vertices_to_pick.begin()->second };
        vertices_to_pick.erase(vertices_to_pick.begin());
        ordered.erase(d_n);

        vector<vertex_t> updates;
        updates.reserve(d_n.outdegree);
        while (d_n.outdegree > 0) {
            if (ordered.empty()) {
                return nullopt;
            }
            updates.push_back(*ordered.begin());
            ordered.erase(ordered.begin());
            vertices_to_pick.erase(updates.back().label);
            d_n.outdegree--;
        }

        for (auto d : updates) {
            if (d.indegree == 0) {
                return nullopt;
            }
            d.indegree--;
            edges.push_back({d_n.label, d.label});
            insert(ordered, vertices_to_pick, d);
        }
        insert(ordered, vertices_to_pick, d_n);
    }

    return edges;
}

int main () {
    int_t n;
    cin >> n;
    vector<vertex_t> sequence(n);
    for (int_t i = 0; i < n; i++) {
        sequence[i].label = i;
    }
    for (int_t i = 0; i < n; i++) {
        cin >> sequence[i].outdegree;
    }
    for (int_t i = 0; i < n; i++) {
        cin >> sequence[i].indegree;
    }

    const auto result{ erdos_miklos_toroczkai(sequence) };

    if (result.has_value()) {
        cout << n << " " << result->size() << '\n';
        for (auto [a, b] : result.value()) {
            cout << a+1 << " " << b+1 << '\n';
        }
    }
    else {
        cout << "impossible" << endl;
    }
    return 0;
}
