#include <algorithm>
#include <iostream>
#include <optional>
#include <vector>

using namespace std;

using int_t = int64_t;

using edge_t = pair<int_t, int_t>;

struct vertex_t {
    int_t label;
    int_t outdegree;
    int_t indegree;
};

bool operator<(const vertex_t a, const vertex_t b) {
    return a.indegree == b.indegree ?
            (a.outdegree == b.outdegree ? a.label < b.label : a.outdegree > b.outdegree) :
            a.indegree > b.indegree;
}

optional<vector<edge_t>> erdos_miklos_toroczkai_naive(vector<vertex_t> sequence) {
    int_t n = static_cast<int_t>(sequence.size());

    vector<edge_t> edges;

    while (true) {
        sequence.erase(remove_if(sequence.begin(), sequence.end(), [](const vertex_t d) {
            return d.indegree + d.outdegree == 0;
        }), sequence.end());

        if (sequence.empty()) {
            break;
        }

        const auto it{ find_if(sequence.begin(), sequence.end(), [](const vertex_t d) {
            return d.outdegree > 0;
        })};
        if (it == sequence.end()) {
            return nullopt;
        }

        if (sequence.size() == 1) {
            return nullopt;
        }

        const auto ind{ distance(sequence.begin(), it) };
        swap(sequence[ind], sequence.back());
        auto d_n{ sequence.back() };
        sequence.pop_back();
        sort(sequence.begin(), sequence.end());

        for (int_t i = 0; d_n.outdegree > 0; i++) {
            if (i >= static_cast<int_t>(sequence.size())) {
                return nullopt;
            }
            if (sequence[i].indegree == 0) {
                return nullopt;
            }
            edges.push_back({d_n.label, sequence[i].label});
            sequence[i].indegree--;
            d_n.outdegree--;
        }
        if (d_n.indegree + d_n.outdegree > 0) {
            sequence.push_back(d_n);
        }
    }

    return edges;
}

int main () {
    int n;
    cin >> n;
    vector<vertex_t> sequence(n);
    for (int_t i = 0; i < n; i++) {
        sequence[i].label = i;
    }
    for (int_t i = 0; i < n; i++) {
        cin >> sequence[i].outdegree;
    }
    for (int_t i = 0; i < n; i++) {
        cin >> sequence[i].indegree;
    }

    const auto result{ erdos_miklos_toroczkai_naive(sequence) };

    if (result.has_value()) {
        cout << n << " " << result->size() << endl;
        for (auto [a, b] : result.value()) {
            cout << a+1 << " " << b+1 << endl;
        }
    }
    else {
        cout << "impossible" << endl;
    }
    return 0;
}
