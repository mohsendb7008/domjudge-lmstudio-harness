import re
import sys

max_n = 0
max_m = 0

if len(sys.argv) >= 2:
    for arg in sys.argv[1:]:
        if arg.startswith('max_n=') or arg.startswith('max_m='):
            exec(arg)

line = sys.stdin.readline()
assert re.match("^(0|[1-9][0-9]*)\n$", line)
n = int(line.rstrip('\n'))
assert 0 <= n <= max_n

total = 0
for _ in range(2):
    line = sys.stdin.readline()
    assert re.match("^((0|[1-9][0-9]*)( (0|[1-9][0-9]*))*)?\n", line)
    sequence = list(map(int, line.split()))
    assert len(sequence) == n
    for x in sequence:
        assert 0 <= x <= n
        total += x

assert 0 <= total <= 2 * max_m, f"Degree sum {total} is not below limit of {2*max_m}"

assert sys.stdin.read() == ''

sys.exit(42)
